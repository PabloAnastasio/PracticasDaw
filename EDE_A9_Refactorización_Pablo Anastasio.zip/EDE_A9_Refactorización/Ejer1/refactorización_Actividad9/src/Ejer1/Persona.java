package Ejer1;

import java.util.*;

public class Persona {

	 protected String numeroDeTelefono;
	
	public Persona(String numeroDeTelefono){
		
		super();
		this.numeroDeTelefono=numeroDeTelefono;
		
	}
	
	public String getNumeroDeTelefono(){
		return numeroDeTelefono;
		
	}
	
	public void setnumeroDeTelefono(String numeroDeTelefono){
		this.numeroDeTelefono= numeroDeTelefono;
		
	}
}



		 


