package Ejer1;

public class Prestamo {

}
