package refactorizacion_Ejer3_EDE;

import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.TestCase;

public class FechaTest extends TestCase{

		private Fecha fechaCorrecta = new Fecha(17,5,2017);
		private Fecha mesIncorrecto1 = new Fecha(31,51,2017);
		private Fecha mesIncorrecto2 = new Fecha(12,51,2017);
		private Fecha mesNomviembre = new Fecha(31,11,2017);
		private Fecha mesDiciembre = new Fecha(31,12,2017);
		private Fecha mesFebrero = new Fecha(30,2,2017);
		private Fecha mesFebreroBi = new Fecha(29,2,2017);
	@Test
	public void testValida() {
		
		assertTrue(fechaCorrecta.valida());
	}

}
