package EDE_A6;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import JUNIT.Calculadora;

public class LineTest {
	
	Line line;
	double delta=0.0001;
	Line l = null;
	
	@Before
	public void antesDelTest()
	{
		 line=new Line(1,2,3,4);
	}


	@Test
	public void getSlope()
	{		
		double valorReal = line.getSlope();
		double valorEsperado = (1 -2) / (3 -1);
		assertEquals(valorEsperado,valorReal,delta);
	}
	
	@Test
	public void getDistance()
	{	
		double valorReal = line.getDistance();
		double valorEsperado = Math.sqrt((3 - 1) * (3 - 1) + (4 - 2) * (4 - 2));
		assertEquals(valorEsperado,valorReal,delta);
	}

	@Test 
	public void parallelTo()
	{
		Line l = new Line(5,2,3,4);
		boolean valorReal =  line.parallelTo(l);
		
		assertTrue(!valorReal);
		assertFalse(valorReal);
		
	}
}
